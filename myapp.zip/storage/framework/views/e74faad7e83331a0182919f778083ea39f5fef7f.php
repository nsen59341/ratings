

<?php $__env->startSection('content'); ?>

<main id="main" class="main review">

    <div class="pagetitle">
      <h1>Reviews</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="/">Home</a></li>
          <li class="breadcrumb-item active">Reviews</li>
        </ol>
      </nav>
    </div>

    <section class="section">
      <div class="row align-items-top">

       <?php if(count($reviews) >= 1): ?>
       <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-6">
          <!-- Default Card -->
          <div class="card">
            <!-- <img src="http://127.0.0.1:8000/images/card.jpg" class="card-img-top" > -->
            <div class="card-body">
              <h5 class="card-title"><?php echo e($review->user->name); ?></h5>
              <?php echo $review->review_statements; ?>

              <br><br>
              <a href="<?php echo e(url('reviews/'.$review->id.'/edit')); ?>" class="card-link">Edit</a>
              <form action="<?php echo e(route('reviews.destroy', $review->id)); ?>" id="del-form-<?php echo e($review->id); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type='button' class="card-link" onclick="del_confirm(<?php echo e($review->id); ?>)">Delete</button>
              </form>
            </div>
          </div><!-- End Default Card -->
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

      </div>

      <script>
        function del_confirm(id){
          var is_confrm = confirm("Are you sure you want to delete the post?");

          if( is_confrm == true ){
            document.getElementById("del-form-"+id).submit();
          }

        }
      </script>

    </section>

</main><!-- End #main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\trustreviews\myapp\resources\views/reviews.blade.php ENDPATH**/ ?>